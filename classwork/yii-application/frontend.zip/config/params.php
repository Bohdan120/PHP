<?php
return [
    'adminEmail' => 'admin@example.com',
    'maxNewsInList' => 4,
    'shortTextLimit' => 4
];
