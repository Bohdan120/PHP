<?php



namespace frontend\models\example;

class Human {
    use SpecialTrait;

    // public function walk() {
    //     echo 'I walk';
    // }

}