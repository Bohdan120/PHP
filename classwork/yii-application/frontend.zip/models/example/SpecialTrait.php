<?php



namespace frontend\models\example;

trait SpecialTrait {
    public function walk() {
        echo 'I walk asdasdsa';
    }
}