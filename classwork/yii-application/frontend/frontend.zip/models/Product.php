<?php


namespace frontend\models;

use yii\db\ActiveRecord;


class Book extends ActiveRecord {
}


?>