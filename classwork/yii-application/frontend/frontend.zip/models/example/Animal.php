<?php



namespace frontend\models\example;

class Animal {
    use SpecialTrait;
    // public function walk() {
    //     echo 'I walk';
    // }


}